#include <stdio.h>

int main(void)
{
    int a[50], b[10][10];
    int n, rows, cols;
    int i, j, sum1 = 0, sum2 = 0;

    printf("Enter the number of elements in 1D array: ");
    scanf("%d", &n);

    if (n < 1 || n > 50)
    {
        printf("Enter a size between 1 and 50.\n");
        return 0;
    }

    printf("Enter %d elements:\n", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("\n1D Array Elements:\n");
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
        sum1 = sum1 + a[i];
    }
    printf("\nSum of 1D Array = %d\n", sum1);

    printf("\nEnter the number of rows in 2D array: ");
    scanf("%d", &rows);
    printf("Enter the number of columns in 2D array: ");
    scanf("%d", &cols);

    if (rows < 1 || rows > 10 || cols < 1 || cols > 10)
    {
        printf("Rows and columns must be between 1 and 10.\n");
        return 0;
    }

    printf("Enter the elements of 2D array:\n");
    for (i = 0; i < rows; i++)
        for (j = 0; j < cols; j++)
            scanf("%d", &b[i][j]);

    printf("\n2D Array Elements:\n");
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < cols; j++)
        {
            printf("%d\t", b[i][j]);
            sum2 = sum2 + b[i][j];
        }
        printf("\n");
    }

    printf("Sum of 2D Array = %d\n", sum2);

    return 0;
}
